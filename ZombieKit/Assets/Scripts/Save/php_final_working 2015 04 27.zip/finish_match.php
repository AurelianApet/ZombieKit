<?
////////////////////////////////////////////////////////////////////
// City-Building Starter Kit
// Licensed Under http://citybuildingkit.com/license.html
// Social Raiding Results Demo - This script uploads, stores, and distributes map files for raiding.
//
// WARNING: There is a security risk with using the mapid as the filename from this demo. 
// Replace this with your own internal variable, such a filename from a database.
// Failure to change this will leave your server at risk! Do not use this demo file without modifications since this is a demo document and others will have access to it too!
//
// Downloaded from http://www.citybuildingkit.com
// (c) 2014 by IntroWizard, LLC
// Run like: http://www.citybuildingkit.com/finish_match.php?mapid=XXXX&savefile=XXXX.txt (The file must be uploaded as a POST request)
//
// Variables:
// mapid - a unique identifier for every individual game player, use however you wish
// savefile - the player's map data to save, before distributing another map
// Output: 
// A random map file will be read, download the output.
// If an error, output will be just a 0. This means the savefile wasn’t posted, or the mapid was forgotten
//
// For testing change "your@email.com" below to your email to receive notification of the variables.
////////////////////////////////////////////////////////////////////

foreach ($_REQUEST as $key => $value)
    	$message .= "Field ".htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
    $text = print_r($_FILES, true);
    mail("your@email.com","FINISHMATCH CITY KIT INFO","(text: $text) (uid: ".$_REQUEST["mapid"].") and file is ".$_FILES['savefile']['name'].") ---VARIABLES----\r\n".$message." \r\n----END ---referrer:".$_SERVER['HTTP_REFERER']); 


 $newname = $_REQUEST["mapid"].'.txt';	//The name for the file, in this case the mapid
 $target = './maps/'.$newname;	//Where to save the file


//Check if the request is value
if($_REQUEST["mapid"]&&$_FILES['savefile']['name']){
/*//Attack data
$attack_data = file_get_contents($_FILES['savefile']['tmp_name']); //Reads the file
$add_to_attack_file = "
###_ATTACK_DATA_START_###
".$attack_data."
###_FINISH_###
";

$fWrite = fopen($target,"a"); //opens the attack file, if it doesn't exist it creates one
$wrote = fwrite($fWrite, $add_to_attack_file); //adds the attack data to the end of hte file
fclose($fWrite); // closes the file
exit;
*/
 move_uploaded_file( $_FILES['savefile']['tmp_name'], $target); //Save the file

 echo "1";
//Now runs the random map file and displays the random map data
exit;

} elseif($_REQUEST["get_user_map"]==1&&$_REQUEST["mapid"]) {
echo file_get_contents($target); //opens and displays the attack file contents

	if($_REQUEST["delete"]==1){
		$fWrite = fopen($target,"w"); //now creates a blank attack file to overwrite
		$wrote = fwrite($fWrite, ""); //overwrites the file with blank
		fclose($fWrite); // closes and saves, so the attack file on the server is empty since you've downloaded the data
	}
exit;
} else {
//If no mapid or map file was posted, return an error message
echo "0";
exit;
}


?>

