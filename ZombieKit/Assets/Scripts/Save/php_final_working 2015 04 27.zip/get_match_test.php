<! -- ----------- -->
<! -- ----------- -->
<!-- This is a development page for uploading map files to test with. WARNING: Rename this page as others have access to the documentation for the City Building Kit and can target your server if they discover this file. Changing the filename or securing the folder should be the first things you do to protect your server. -->
<! -- ----------- -->
<! -- ----------- -->

<html>
<body>
    <?

if($_REQUEST["delete"]==1&&$_REQUEST["mapfile"]){
    unlink("maps/".$_REQUEST["mapfile"]);
echo "<h1><font color=red>".$_REQUEST["mapfile"]." deleted</font></h1><br>";
}

?>
<h1>Test Form for Uploading Maps</h1>
<h3>(don't use with your script! this is just a test form for you to use with your internet browser to manage maps, or upload a demo manually)</h3>
 <form method="post" action="get_match.php" enctype="multipart/form-data">
            mapid: <input type="text" name="mapid" size="30" value=""/> (only a value, like xAg36a -- no .txt)<br>
            Map File:<input type="file" name="savefile" id="savefile" /> (.txt)<br>
            <input type="submit" value='Save Map'/>
        </form>
<hr>
<h1>List of Maps Uploaded</h1><br>
<?php
    if ($handle = opendir('maps')) {
        while (false !== ($entry = readdir($handle))) {
            if ($entry != "." && $entry != "..") {
                echo "<a href=http://inosfera.orgfree.com/maps/$entry target=_blank>$entry</a>\n - (<a href=get_match_test.php?delete=1&mapfile=$entry>X</a>)<br> ";
                $total++;
            }
        }
        closedir($handle);
   }
   if($total<1){ echo "No maps uploaded."; }
?>
<hr>
<!-- Start 1FreeCounter.com code -->
  
  <script language="JavaScript">
  var data = '&r=' + escape(document.referrer)
	+ '&n=' + escape(navigator.userAgent)
	+ '&p=' + escape(navigator.userAgent)
	+ '&g=' + escape(document.location.href);

  if (navigator.userAgent.substring(0,1)>'3')
    data = data + '&sd=' + screen.colorDepth 
	+ '&sw=' + escape(screen.width+'x'+screen.height);

  document.write('<a href="http://www.1freecounter.com/stats.php?i=110278" target=\"_blank\" >');
  document.write('<img alt="Free Counter" border=0 hspace=0 '+'vspace=0 src="http://www.1freecounter.com/counter.php?i=110278' + data + '">');
  document.write('</a>');
  </script>

<!-- End 1FreeCounter.com code -->

</body>
</html>