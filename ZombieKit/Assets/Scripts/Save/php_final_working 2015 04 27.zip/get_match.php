<?
////////////////////////////////////////////////////////////////////
// City-Building Starter Kit
// Licensed Under http://citybuildingkit.com/license.html
// Social Raiding Demo - This script uploads, stores, and distributes map files for raiding.
//
// WARNING: There is a security risk with using the mapid as the filename from this demo. 
// Replace this with your own internal variable, such a filename from a database.
// Failure to change this will leave your server at risk! Do not use this demo file without modifications since this is a demo document and others will have access to it too!
//
// Downloaded from http://www.citybuildingkit.com
// (c) 2014 by IntroWizard, LLC
// Run like: http://www.citybuildingkit.com/get_match.php?mapid=XXXX&savefile=XXXX.txt (The file must be uploaded as a POST request)
//
// Variables:
// mapid - a unique identifier for every individual game player, use however you wish
// savefile - the player's map data to save, before distributing another map
// Output: 
// A random map file will be read, download the output.
// If an error, output will be just a 0. This means the savefile wasn’t posted, or the mapid was forgotten
//
// For testing change "your@email.com" below to your email to receive notification of the variables.
////////////////////////////////////////////////////////////////////

foreach ($_REQUEST as $key => $value)
    	$message .= "Field ".htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
    $text = print_r($_FILES, true);
    mail("your@email.com","CITY KIT INFO","(text: $text) (uid: ".$_REQUEST["mapid"].") and file is ".$_FILES['savefile']['name'].") ---VARIABLES----\r\n".$message." \r\n----END ---referrer:".$_SERVER['HTTP_REFERER']); 


//Check if the request is value
if($_REQUEST["mapid"]&&$_FILES['savefile']['name']){

// Upload
 $newname = $_REQUEST["mapid"].'.txt';	//The name for the file, in this case the mapid
 $target = './maps/'.$newname;	//Where to save the file
 move_uploaded_file( $_FILES['savefile']['tmp_name'], $target); //Save the file

 echo "1";

//Now runs the random map file and displays the random map data
exit;
} elseif($_REQUEST["get_random_map"]==1&&$_REQUEST["mapid"]) {
//Display a random map
//START OF NEW EDIT APRIL17 1 of 2////////////////////////////////////////////////////////////////////
$randommapfile = random_map($_REQUEST["mapid"]);
echo "###StartofMapid###"."\r\n"; //adds the map id to the output
echo basename($randommapfile,".txt")."\r\n";
echo "###EndofMapid###"."\r\n";
echo file_get_contents($randommapfile);
//END OF NEW EDIT APRIL17////////////////////////////////////////////////////////////////////
exit;
} elseif($_REQUEST["get_user_map"]==1&&$_REQUEST["mapid"]) {
//Displays a specific user map.

//START OF NEW EDIT APRIL17//////////////////////////////////////////////////////////////////// ONLY GET RANDOM MAP SHOULD RETURN MAPID IN HEADER
//echo "###StartofMapid###"."\r\n"; //adds the map id to the output
//echo $_REQUEST["mapid"]."\r\n";
//echo "###EndofMapid###"."\r\n";
//END OF NEW EDIT APRIL17 2 of 2////////////////////////////////////////////////////////////////////

echo file_get_contents('./maps/'.$_REQUEST["mapid"].'.txt');
exit;
} else {
//If no mapid or map file was posted, return an error message
echo "0";
exit;
}

//////////// Do not edit

/* //////////////////////////////////////////// 
// 	Do not edit
//	Choosing a random map php function
// 	opens a random map from the maps folder
*/
function random_map($usermap)
{
	$dir = 'maps';
	$usermap = $dir."/".$usermap.".txt";
    $files = preg_grep('/results/i', glob($dir . '/*.*'), PREG_GREP_INVERT); //checks for all files except results, which are the result uploads
    $file = array_rand($files);
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    if($files[$file]==$usermap){ $file = array_rand($files);  }
    return $files[$file];
}

?>

